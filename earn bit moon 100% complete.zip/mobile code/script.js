// Connection check karne ke liye test data
console.log("Firebase Database Object:", database);

database.ref("test_connection").set({
    message: "Firebase is connected!",
    time: new Date().toLocaleString()
}).then(() => {
    console.log("Success: Data Firebase mein chala gaya hai!");
}).catch((error) => {
    console.error("Firebase Error:", error);
});



// === TRANSACTION HISTORY SAVE FUNCTION ===

function saveTransaction(type, amount, status) {
    const userId = localStorage.getItem('userPhone');
    console.log("Saving for User:", userId); // Debugging line

    if (!userId) {
        alert("Error: User ID nahi mili. Dobara login karein.");
        return;
    }

    const historyKey = 'history_' + userId;
    let history = JSON.parse(localStorage.getItem(historyKey)) || [];
    
    const newTrx = {
        id: "TRX" + Math.floor(Math.random() * 1000000),
        type: type,
        amount: amount,
        status: status,
        date: new Date().toLocaleString()
    };
    
    history.unshift(newTrx); // Nayi history sab se upar aayegi
    localStorage.setItem(historyKey, JSON.stringify(history));
    console.log("Data Saved Successfully!"); // Debugging line
}

// === PAGE LOAD LOGIC ===
// URL se referral code check karna
const urlParams = new URLSearchParams(window.location.search);
const refCode = urlParams.get('rf');

if (refCode) {
    // Agar link mein code hai, toh usay temporary save kar lo
    localStorage.setItem('referredBy', refCode);
    console.log("Referred by: " + refCode);
}

window.onload = function() {
    const userStatus = localStorage.getItem('isLoggedIn');
    if (userStatus === 'true') {
        showDashboard();
    }
};
// === DASHBOARD DIKHANE KA FUNCTION ===

function showDashboard() {
    switchPage('dashboardPage');

    const phone = localStorage.getItem('userPhone');
    if (!phone) return;

    // === 1. Referral Link Logic ===
    const refIDPartial = phone.slice(-5); 
    const baseReferralURL = 'https://earnbitmoon.com/ref?id='; 
    const uniqueLink = baseReferralURL + refIDPartial; 

    const linkBox = document.getElementById('referLink');
    if (linkBox) {
        linkBox.value = uniqueLink;
    }

    // === 2. Firebase Live Listener ===
    // 'on' use karne se data automatic update hota rahega
    database.ref('users/' + phone).on('value', (snapshot) => {
        const data = snapshot.val();
        if (data) {
            // Name Display
           
           processAutomaticProfit(data, phone);  if(document.getElementById('displayUserName')) {
                document.getElementById('displayUserName').innerText = data.name || "User";
            }
            // Withdrawal Balance
            if(document.getElementById('mainBalance')) {
                document.getElementById('mainBalance').innerText = parseFloat(data.balance || 0).toFixed(2);
            }
            // Current Deposit Balance
            if(document.getElementById('totalDeposit')) {
                document.getElementById('totalDeposit').innerText = "Rs " + parseFloat(data.totalDeposit || 0).toFixed(2);
            }

            // === Active Plan Information ===
            if(document.getElementById('displayPlanName')) {
                document.getElementById('displayPlanName').innerText = data.activePlan || "No Active Plan";
            }
            if(document.getElementById('displayPlanAmount')) {
                document.getElementById('displayPlanAmount').innerText = "Rs " + parseFloat(data.activePlanAmount || 0).toFixed(2);
            }
        }
    });
}


    // 3. History Load karein (Agar function defined ho)
    if (typeof loadHistory === "function") {
        loadHistory();
    }



    // 3. History Load karein (Image lines 84-88)
    if (typeof loadHistory === "function") {
        loadHistory();
    }



    // 3. History Load karein (Jo pehle humne banayi thi)
    if (typeof loadHistory === "function") {
        loadHistory();
    }



function switchPage(pageId) {
    document.getElementById('loginPage').style.display = 'none';
    document.getElementById('signupPage').style.display = 'none';
    document.getElementById('dashboardPage').style.display = 'none';
    document.getElementById(pageId).style.display = (pageId === 'dashboardPage') ? 'block' : 'flex';
}

// === COPY REFERRAL LINK (Added Function) ===
function copyLink() {
    const copyText = document.getElementById("referLink");
    copyText.select();
    copyText.setSelectionRange(0, 99999); // Mobile ke liye
    navigator.clipboard.writeText(copyText.value);
    alert("Referral Link Copied: " + copyText.value);
}

// === SIGNUP LOGIC ===
document.getElementById('signupForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('regName').value;
    const phone = document.getElementById('regPhone').value;
    const pass = document.getElementById('regPass').value;
    
    // Check karein ke kya koi referral code saved hai
    const referredBy = localStorage.getItem('referredBy') || "none";

    // User ka data save karna
    localStorage.setItem('userName_' + phone, name);
    localStorage.setItem('userPhone_' + phone, phone);
    localStorage.setItem('userPass_' + phone, pass);
    localStorage.setItem('u_referredBy_' + phone, referredBy); // Kis ne invite kiya

    // Global list taake login mein asani ho (Optional improvement)
    localStorage.setItem('userPhone', phone);
    localStorage.setItem('userPass', pass);
    localStorage.setItem('userName', name);

    alert("Account Created! Referral: " + referredBy);
    localStorage.removeItem('referredBy'); // Signup ke baad temp code delete kar dein
    switchPage('loginPage');
});

// === SIGNUP LOGIC (FIREBASE) ===
document.getElementById('signupForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('regName').value;
    const phone = document.getElementById('regPhone').value;
    const pass = document.getElementById('regPass').value;
    
    // Check karein ke user pehle se register toh nahi?
    database.ref('users/' + phone).once('value', (snapshot) => {
        if (snapshot.exists()) {
            alert("Ye number pehle se registered hai! Login karein.");
        } else {
            // Naya user save karein
            database.ref('users/' + phone).set({
                name: name,
                phone: phone,
                password: pass,
                balance: 0,
                totalDeposit: 0,
                tasksCompleted: 0,
                referredBy: localStorage.getItem('referredBy') || "none",
                status: "active",
                joinedDate: new Date().toLocaleString()
            }).then(() => {
                alert("Account Created Successfully! Please Login.");
                switchPage('loginPage');
            }).catch((error) => {
                alert("Error: " + error.message);
            });
        }
    });
});



// === DASHBOARD LOGIC ===
function loadHistory() {
    const phone = localStorage.getItem('userPhone');
    const historyContainer = document.getElementById('historyContainer'); 

    if (!phone || !historyContainer) return;

    // '.on' use karne se Firebase mein status change hote hi website par bhi badal jayega
    database.ref('users/' + phone + '/history').on('value', (snapshot) => {
        if (!snapshot.exists()) {
            historyContainer.innerHTML = "<p style='color:gray;'>No transactions yet.</p>";
            return;
        }

        let html = "<h3>Transaction History</h3>";
        
        // Data ko ulta dikhane ke liye (Newest first)
        let historyArray = [];
        snapshot.forEach((child) => {
            historyArray.unshift(child.val()); 
        });

        historyArray.forEach((data) => {
            // Status ke mutabiq rang (Color) set karein
            let statusColor = "orange"; // Pending
            if (data.status === "Approved" || data.status === "Success") statusColor = "#00ff00"; // Green
            if (data.status === "Rejected") statusColor = "#ff0000"; // Red

            html += `
                <div style="background: #222; padding: 12px; border-radius: 8px; margin-bottom: 10px; border-left: 4px solid ${statusColor};">
                    <div style="display: flex; justify-content: space-between;">
                        <strong style="color: white;">${data.type}</strong>
                        <span style="color: ${statusColor}; font-weight: bold;">${data.status}</span>
                    </div>
                    <div style="font-size: 14px; color: #bbb; margin-top: 5px;">
                        Amount: Rs ${data.amount} <br>
                        ${data.trxId ? "TrxID: " + data.trxId : "Account: " + data.accountNumber} <br>
                        <small>${data.timestamp}</small>
                    </div>
                </div>
            `;
        });
        historyContainer.innerHTML = html;
    });
}
// === NAVIGATION & MENUS ===
function toggleMenu() {
    document.getElementById('sidebar').classList.toggle('active');
}

function hideAll() {
    const ids = ['welcomeCard', 'depositFormContainer', 'withdrawFormContainer', 'vipPage', 'dailyTaskContainer', 'historyContainer', 'termsPage', 'aboutPage'];
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    });
}


function closeAll() {
    hideAll();
    document.getElementById('welcomeCard').style.display = 'block';
}

// Sidebar links handlers
function openDeposit() { hideAll(); document.getElementById('depositFormContainer').style.display = 'block'; toggleMenu(); }
function openWithdraw() { hideAll(); document.getElementById('withdrawFormContainer').style.display = 'block'; toggleMenu(); }
function openVIP() { hideAll(); document.getElementById('vipPage').style.display = 'block'; toggleMenu(); }
function openDailyTask() { hideAll(); document.getElementById('dailyTaskContainer').style.display = 'block'; toggleMenu(); }
function openTerms() { hideAll(); document.getElementById('termsPage').style.display = 'block'; toggleMenu(); }

// === LOGOUT LOGIC ===
function logout() {
    localStorage.setItem('isLoggedIn', 'false');
    switchPage('loginPage');
    location.reload();
}

// === BUY PLAN (VIP) LOGIC ===

function buyPlan(amount, planName) {
    const userId = localStorage.getItem('userPhone');
    if (!userId) return alert("Please login first!");

    const userRef = database.ref('users/' + userId);

    userRef.once('value', (snapshot) => {
        const userData = snapshot.val();
        if (!userData) return;

        // 1. Firebase se 'totalDeposit' aur 'balance' lein
        let currentTotalDeposit = parseFloat(userData.totalDeposit || 0);
        let currentMainBalance = parseFloat(userData.balance || 0);

        // 2. Check karein ke Total Deposit mein paise hain ya nahi
        if (currentTotalDeposit < amount) {
            alert("Aapka Total Deposit balance kam hai! " + planName + " ke liye Rs " + amount + " chahiye.");
            return;
        }

        // 3. Profit Percentage Logic (Aapke HTML ke mutabiq)
        let profitPercent = 4;
        if (planName === 'VIP 2') profitPercent = 4.5;
        if (planName === 'VIP 3') profitPercent = 5;
        if (planName === 'VIP 4') profitPercent = 6;
        if (planName === 'VIP 5') profitPercent = 7.5;
        if (planName === 'VIP 6') profitPercent = 9;
        if (planName === 'VIP 7') profitPercent = 10;

        const dailyProfit = (amount * profitPercent) / 100;
        const purchaseTime = new Date().getTime();

        // 4. Update Logic: Total Deposit se minus hoga, Balance mein profit jayega
        userRef.update({
            totalDeposit: currentTotalDeposit - amount, // Investment minus ho gayi
            balance: currentMainBalance + dailyProfit,   // Pehla profit foran mil gaya
            activePlan: planName,
            activePlanAmount: amount,
            planStatus: 'Active',
            planStartTime: purchaseTime,
            lastProfitClaim: purchaseTime
        }).then(() => {
            alert("your plan activate successfully! " + planName + ".\"!");
            
            // Transaction history mein record save karein
            savePurchaseHistory(userId, planName, amount);
            
        }).catch((error) => {
            alert("Update fail ho gaya: " + error.message);
        });
    });
}

// History save karne ka function
function savePurchaseHistory(phone, plan, price) {
    database.ref('users/' + phone + '/history').push({
        type: "Plan Purchase",
        plan: plan,
        amount: price,
        status: "Success",
        date: new Date().toLocaleString()
    });
}

// History save karne ke liye helper function
function savePurchaseHistory(phone, plan, price) {
    database.ref('users/' + phone + '/history').push({
        type: "Plan Purchase",
        plan: plan,
        amount: price,
        status: "Success",
        date: new Date().toLocaleString()
    });
}

// === DAILY TASK LOGIC ===
function updateTaskTimer() {
    const userId = localStorage.getItem('userPhone'); 
    const lastClaim = localStorage.getItem('lastTaskClaim_' + userId); 
    
    const claimBtn = document.querySelector('#dailyTaskContainer .login-btn');
    const timerDisplay = document.getElementById('taskMessage');

    if (!lastClaim) {
        if(claimBtn) {
            claimBtn.disabled = false;
            claimBtn.innerText = "Claim Rs 5";
            claimBtn.style.background = "linear-gradient(to right, #00d4ff, #00f5d4)";
        }
        if(timerDisplay) timerDisplay.innerText = "You can claim your reward now!";
        return;
    }

    const lastTime = parseInt(lastClaim);
    const currentTime = new Date().getTime();
    const twentyFourHours = 24 * 60 * 60 * 1000;
    const timeLeft = (lastTime + twentyFourHours) - currentTime;

    if (timeLeft > 0) {
        if(claimBtn) {
            claimBtn.disabled = true;
            claimBtn.style.background = "#555";
            claimBtn.innerText = "Locked";
        }

        const hours = Math.floor((timeLeft / (1000 * 60 * 60)) % 24);
        const minutes = Math.floor((timeLeft / (1000 * 60)) % 60);
        const seconds = Math.floor((timeLeft / 1000) % 60);

        if(timerDisplay) {
            timerDisplay.innerText = `Next claim in: ${hours}h ${minutes}m ${seconds}s`;
        }
        setTimeout(updateTaskTimer, 1000);
    } else {
        if(claimBtn) {
            claimBtn.disabled = false;
            claimBtn.style.background = "linear-gradient(to right, #00d4ff, #00f5d4)";
            claimBtn.innerText = "Claim Rs 5";
        }
        if(timerDisplay) timerDisplay.innerText = "You can claim your reward now!";
    }
}

function claimDailyProfit() {
    const userId = localStorage.getItem('userPhone');
    if (!userId) return alert("Please login first!");

    const userRef = database.ref('users/' + userId);

    userRef.once('value', (snapshot) => {
        const userData = snapshot.val();
        if (!userData) return;

        const now = new Date().getTime();
        const lastClaim = userData.lastProfitClaim || 0;
        const gap = 24 * 60 * 60 * 1000; 

        if (now - lastClaim < gap) {
            const remaining = gap - (now - lastClaim);
            const hours = Math.floor(remaining / (1000 * 60 * 60));
            const mins = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
            alert(`Aap aaj ka reward le chuke hain. Agla reward ${hours}h ${mins}m baad milega.`);
            return;
        }

        const freeReward = 5; 
        const currentBalance = parseFloat(userData.balance || 0);
        const newBalance = currentBalance + freeReward;

        userRef.update({
            balance: newBalance,
            lastProfitClaim: now
        }).then(() => {
            // Screen par balance foran update karne ke liye
            if(document.getElementById('mainBalance')) {
                document.getElementById('mainBalance').innerText = newBalance.toFixed(2);
            }
            
            alert("Mubarak ho! Rs 5 aapke balance mein add kar diye gaye hain.");
            
            // Transaction history mein "Received" add karna
            database.ref('users/' + userId + '/history').push({
                type: "Daily Free Task",
                status: "Received",  // Ye field "undefined" ko khatam karegi
                amount: freeReward,
                date: new Date().toLocaleString()
            });
        }).catch((error) => {
            console.error("Error updating balance:", error);
        });
    });
}



// === HISTORY DISPLAY LOGIC ===
function openHistory() {
    hideAll();
    const container = document.getElementById('historyContainer');
    if (container) container.style.display = 'block';

    const userId = localStorage.getItem('userPhone');
    if (!userId) {
        alert("Session expired. Please login again.");
        return;
    }

    const historyKey = 'history_' + userId;
    let history = [];
    try {
        history = JSON.parse(localStorage.getItem(historyKey)) || [];
    } catch (e) {
        history = [];
    }

    const listContainer = document.getElementById('transactionList');
    if (!listContainer) return;

    if (history.length === 0) {
        listContainer.innerHTML = `<p style="text-align:center; color:#888; padding:20px;">Abhi tak koi transaction nahi hui.</p>`;
    } else {
        listContainer.innerHTML = history.map(trx => `
            <div style="background: rgba(255,255,255,0.05); padding: 12px; border-radius: 8px; margin-bottom: 10px; border-left: 4px solid ${trx.type === 'Deposit' ? '#00d4ff' : '#ff4757'};">
                <div style="display: flex; justify-content: space-between;">
                    <b style="color:white;">${trx.type}</b>
                    <span style="color: ${trx.status === 'Pending' ? '#ffb703' : '#00f5d4'}; font-size: 0.8rem;">${trx.status}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-top: 5px; font-size: 0.85rem; color: #ccc;">
                    <span>Rs ${trx.amount}</span>
                    <span style="font-size: 0.7rem;">${trx.date}</span>
                </div>
            </div>
        `).join('');
    }
    
    if(document.getElementById('sidebar').classList.contains('active')) toggleMenu();
}

// === DEPOSIT FORM HANDLING ===
const depositForm = document.getElementById('depositForm');

if (depositForm) {
    depositForm.addEventListener('submit', function(e) {
        e.preventDefault(); // Page refresh hone se rokne ke liye

        // Aapke HTML IDs ke mutabiq values lena
        const sender = document.getElementById('senderNumber').value;
        const amount = document.getElementById('depositAmount').value;
        const trx = document.getElementById('trxid').value;
        const phone = localStorage.getItem('userPhone'); // Login user ka phone

        // Validation
        if (amount < 500) {
            alert("Minimum deposit Rs 500 hai.");
            return;
        }

        // Firebase mein data bhejna
        const depositData = {
            senderNumber: sender,
            amount: parseFloat(amount),
            trxId: trx,
            userPhone: phone,
            status: "Pending",
            timestamp: new Date().toLocaleString(),
            type: "Deposit"
        };

        // 1. Admin Requests folder mein save karein
        database.ref('adminRequests/deposits').push(depositData)
            .then(() => {
                // 2. User ki apni history mein bhi save karein
                return database.ref('users/' + phone + '/history').push(depositData);
            })
            .then(() => {
                alert("Deposit Request Submitted Successfully!");
                depositForm.reset(); // Form khali kar dein
                if (typeof closeAll === 'function') closeAll(); // Agar popup hai toh band kar dein
            })
            .catch((error) => {
                console.error("Firebase Error:", error);
                alert("Error: Data save nahi ho saka.");
            });
    });
}


// === MAIN FIREBASE DEPOSIT FUNCTION ===
function submitDeposit(amount, trxId) {
    const phone = localStorage.getItem('userPhone');
    if(!phone) return alert("User not logged in!");

    const depositData = {
        type: 'Deposit',
        amount: parseFloat(amount),
        trxId: trxId,
        status: 'Pending',
        timestamp: new Date().toLocaleString(),
        userPhone: phone
    };

    // 1. Admin Requests mein bhejey (Admin approval ke liye)
    database.ref('adminRequests/deposits').push(depositData)
    .then(() => {
        // 2. User ki apni history mein bhi save karein
        return database.ref('users/' + phone + '/history').push(depositData);
    })
    .then(() => {
        alert("Deposit Request Submitted! Admin approval ka intezar karein.");
    })
    .catch((error) => {
        alert("Error: " + error.message);
    });
}



// === WITHDRAW FORM HANDLING (FIXED) ===
const withdrawForm = document.getElementById('withdrawForm');

if (withdrawForm) {
    withdrawForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const phone = localStorage.getItem('userPhone');
        const amount = parseFloat(document.getElementById('withdrawAmount').value);
        const method = document.getElementById('withdrawMethod').value;
        const accName = document.getElementById('withdrawAccountName').value;
        const accNumber = document.getElementById('withdrawAccountNumber').value;

        if (!phone) return alert("Pehle login karein!");

        database.ref('users/' + phone + '/balance').once('value', (snapshot) => {
            const currentBalance = snapshot.val() || 0;

            if (currentBalance >= amount && amount >= 5) {
                
                const withdrawData = {
                    type: 'Withdraw',
                    amount: amount,
                    method: method,
                    accountName: accName,
                    accountNumber: accNumber,
                    status: 'Pending',
                    timestamp: new Date().toLocaleString(),
                    userPhone: phone
                };

                // 1. Admin Requests mein bhejey (Admin approval ke liye)
                database.ref('adminRequests/withdraws').push(withdrawData)
                .then(() => {
                    // 2. IS LINE KO CHECK KAREIN: User ki history folder mein bhi save karein
                    return database.ref('users/' + phone + '/history').push(withdrawData);
                })
                .then(() => {
                    // 3. Balance minus karein
                    return database.ref('users/' + phone).update({
                        balance: currentBalance - amount
                    });
                })
                .then(() => {
                    alert("Withdraw Request Sent!");
                    withdrawForm.reset();
                    if(typeof closeAll === "function") closeAll();
                })
                .catch((err) => alert("Error: " + err.message));

            } else {
                alert("Incomplete Balance! Current balance: Rs " + currentBalance);
            }
        });
    });
}



// === ADMIN APPROVE DEPOSIT (FIREBASE) ===
function approveDeposit(requestId, userPhone, amount) {
    
    // 1. User ka Balance aur Total Deposit update karein
    const userRef = database.ref('users/' + userPhone);
    
    userRef.once('value', (snapshot) => {
        const userData = snapshot.val();
        let newBalance = (userData.balance || 0) + parseFloat(amount);
        let newTotalDeposit = (userData.totalDeposit || 0) + parseFloat(amount);

        // Firebase mein update karein
        userRef.update({
            balance: newBalance,
            totalDeposit: newTotalDeposit
        });

        // 2. Request ko delete kar dein ya status 'Approved' kar dein
        database.ref('adminRequests/deposits/' + requestId).remove();

        alert("Deposit Approved! User balance updated.");
    });
}



// === LOGIN LOGIC (FIREBASE) ===
// Ye code check karega ke jab login form submit ho toh kya karna hai
const loginForm = document.getElementById('loginForm');

if (loginForm) {
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault(); // Page refresh hone se rokne ke liye
        
        const phone = document.getElementById('loginPhone').value;
        const pass = document.getElementById('loginPass').value;

        // Firebase mein 'users' folder ke andar is phone number ko dhoondo
        database.ref('users/' + phone).once('value', (snapshot) => {
            if (snapshot.exists()) {
                const userData = snapshot.val();
                
                // Password match check karein
                if (userData.password === pass) {
                    // 1. Session save karein taake refresh par login khatam na ho
                    localStorage.setItem('isLoggedIn', 'true');
                    localStorage.setItem('userPhone', phone);
                    
                    alert("Login Successful! Dashboard par ja rahe hain...");
                    
                    // 2. Dashboard wala function chalao
                    showDashboard(); 
                } else {
                    alert("Ghalat Password! Dobara check karein.");
                }
            } else {
                alert("Ye number register nahi hai. Pehle Signup karein.");
            }
        }).catch((error) => {
            console.error("Firebase Login Error:", error);
            alert("Connection error: " + error.message);
        });
    });
}

// === LOGOUT LOGIC ===
function logout() {
    localStorage.clear(); // Saara data clear kar dein
    location.reload();    // Page refresh kar ke wapis login par le jayein
}

// === WITHDRAW REQUEST (FIREBASE) ===
function submitWithdraw(amount, method, accountDetails) {
    const phone = localStorage.getItem('userPhone');
    
    // Pehle check karein balance hai bhi ya nahi
    database.ref('users/' + phone + '/balance').once('value', (snapshot) => {
        const currentBalance = snapshot.val() || 0;
        
        if (currentBalance >= amount) {
            const withdrawData = {
                type: 'Withdraw',
                amount: parseFloat(amount),
                method: method,
                details: accountDetails,
                status: 'Pending',
                timestamp: new Date().toLocaleString(),
                userPhone: phone
            };

            // Request bhejey
            database.ref('adminRequests/withdraws').push(withdrawData).then(() => {
                // Balance foran minus kar dein (Pending status ke sath)
                database.ref('users/' + phone).update({
                    balance: currentBalance - amount
                });
                alert("Withdraw request submitted!");
            });
        } else {
            alert("Incomplete Balance!");
        }
    });
}
// === ADMIN APPROVAL LOGIC (FIREBASE) ===
function adminApproveDeposit(userPhone, amount, requestId) {
    const userRef = database.ref('users/' + userPhone);

    // 1. User ka balance aur total deposit update karein
    userRef.once('value', (snapshot) => {
        const userData = snapshot.val();
        if (userData) {
            let newBalance = (userData.balance || 0) + parseFloat(amount);
            let newTotalDeposit = (userData.totalDeposit || 0) + parseFloat(amount);

            userRef.update({
                balance: newBalance,
                totalDeposit: newTotalDeposit
            });

            // 2. User ki History mein status update karein
            database.ref('users/' + userPhone + '/history').once('value', (histSnap) => {
                histSnap.forEach((child) => {
                    if (child.val().trxId === requestId || child.val().amount == amount) {
                        child.ref.update({ status: 'Approved' });
                    }
                });
            });

            // 3. Admin Request folder se delete kar dein taake dobara na dikhe
            database.ref('adminRequests/deposits').once('value', (reqSnap) => {
                reqSnap.forEach((child) => {
                    if (child.val().userPhone === userPhone && child.val().amount == amount) {
                        child.ref.remove();
                    }
                });
            });

            alert("Deposit Approved! Balance aur History update ho gayi hai.");
        }
    });
}

// === ADMIN APPROVAL AUTOMATION ===
function approveTransaction(userPhone, amount, type) {
    // 1. User ki history mein ja kar status 'Approved' karna
    const historyRef = database.ref('users/' + userPhone + '/history');
    
    historyRef.once('value', (snapshot) => {
        snapshot.forEach((child) => {
            const record = child.val();
            // Match karein amount aur type (Deposit/Withdraw) aur jo 'Pending' ho
            if (record.amount == amount && record.type == type && record.status === 'Pending') {
                
                // Status update karein
                child.ref.update({ status: 'Approved' });

                // 2. Agar DEPOSIT hai, toh Balance bhi barhaein
                if (type === 'Deposit') {
                    const userRef = database.ref('users/' + userPhone);
                    userRef.once('value', (userSnap) => {
                        const userData = userSnap.val();
                        let newBalance = (userData.balance || 0) + parseFloat(amount);
                        let newTotalDeposit = (userData.totalDeposit || 0) + parseFloat(amount);
                        
                        userRef.update({
                            balance: newBalance,
                            totalDeposit: newTotalDeposit
                        });
                    });
                }
                
                // 3. Admin Request folder se delete kar dein taake list saaf ho jaye
                const folder = type === 'Deposit' ? 'deposits' : 'withdraws';
                database.ref('adminRequests/' + folder).once('value', (adminSnap) => {
                    adminSnap.forEach((adminChild) => {
                        if (adminChild.val().userPhone === userPhone && adminChild.val().amount == amount) {
                            adminChild.ref.remove();
                        }
                    });
                });

                alert(type + " Approved! Status aur Balance update ho gaya.");
            }
        });
    });
}

function processAutomaticProfit(userData, phone) {
    if (!userData.activePlan || !userData.planStartTime) return;

    const now = new Date().getTime();
    const lastClaim = userData.lastProfitClaim || userData.planStartTime;
    const gap = 24 * 60 * 60 * 1000; // 24 Ghante milliseconds mein

    if (now - lastClaim >= gap) {
        // Kitne din ka profit banta hai? (Agar user 2 din baad aaya to 2 din ka profit)
        const daysPassed = Math.floor((now - lastClaim) / gap);
        
        // Profit percentage nikalne ki logic
        let profitPercent = 4; // Default VIP 1
        if (userData.activePlan === 'VIP 2') profitPercent = 4.5;
        if (userData.activePlan === 'VIP 3') profitPercent = 5;
        // ... baki VIPs ke liye bhi yahan add karein

        const dailyAmount = (parseFloat(userData.activePlanAmount) * profitPercent) / 100;
        const totalProfitToAdd = dailyAmount * daysPassed;

        // Firebase Update
        database.ref('users/' + phone).update({
            balance: parseFloat(userData.balance || 0) + totalProfitToAdd,
            lastProfitClaim: lastClaim + (daysPassed * gap) // Agla cycle pichle claim se start hoga
        }).then(() => {
            console.log(`Automatic Profit Added: Rs ${totalProfitToAdd}`);
            // User ko notification dikhane ke liye
            alert(`Auto-Profit: Rs ${totalProfitToAdd.toFixed(2)} aapke account mein add kar diye gaye hain (${daysPassed} din ka).`);
        });
    }
}

function processAutomaticProfit(userData, phone) {
    if (!userData.activePlan || userData.planStatus !== 'Active') return;

    const now = new Date().getTime();
    const lastClaim = userData.lastProfitClaim || 0;
    const gap = 24 * 60 * 60 * 1000; // 24 Hours in milliseconds

    if (now - lastClaim >= gap) {
        // Kitne dinon ka profit banta hai? (Agar user 2 din baad aye toh 2 din ka profit mile)
        const daysPassed = Math.floor((now - lastClaim) / gap);
        
        // Plan ke mutabiq percentage nikalna
        let profitPercent = 4;
        const plan = userData.activePlan;
        if (plan === 'VIP 2') profitPercent = 4.5;
        else if (plan === 'VIP 3') profitPercent = 5;
        else if (plan === 'VIP 4') profitPercent = 6;
        else if (plan === 'VIP 5') profitPercent = 7.5;
        else if (plan === 'VIP 6') profitPercent = 9;
        else if (plan === 'VIP 7') profitPercent = 10;

        const investment = parseFloat(userData.activePlanAmount || 0);
        const totalProfitToAdd = ((investment * profitPercent) / 100) * daysPassed;

        if (totalProfitToAdd > 0) {
            const newBalance = parseFloat(userData.balance || 0) + totalProfitToAdd;
            
            // Firebase update karein
            database.ref('users/' + phone).update({
                balance: newBalance,
                lastProfitClaim: now // Agle 24 ghante ka cycle ab shuru hoga
            }).then(() => {
                // History mein record add karein
                database.ref('users/' + phone + '/history').push({
                    type: "Auto Profit (" + plan + ")",
                    amount: totalProfitToAdd.toFixed(2),
                    status: "Success",
                    date: new Date().toLocaleString()
                });
                console.log("Automatic profit added: Rs " + totalProfitToAdd);
            });
        }
    }
}
function openAbout() { 
    hideAll(); 
    document.getElementById('aboutPage').style.display = 'block'; 
    toggleMenu(); 
}
